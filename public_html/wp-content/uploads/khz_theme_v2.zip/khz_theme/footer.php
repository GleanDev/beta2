<?php
/**
 * The template for displaying the footer.
 *
 * Contains the closing of the id=main div and all content
 * after.  Calls sidebar-footer.php for bottom widgets.
 *
 * @package WordPress
 * @subpackage Twenty_Ten
 * @since Twenty Ten 1.0
 */
?>
	</div><!-- #main -->
<div class="hFooter"></div>
</div></div><!-- #wrapper -->
	<div id="footer" role="contentinfo">
		<div id="colophon">
			<div class="footer_navi">
				<?php wp_nav_menu( array( 'container_class' => 'navi', 'theme_location' => 'primary'  ) ); ?>
			</div>
			<p class="copyright">Copyright &copy; 2011.KHZ TV.com. All Rights Reserved</p>
		</div><!-- #colophon -->
	</div><!-- #footer -->



<?php
	/* Always have wp_footer() just before the closing </body>
	 * tag of your theme, or you will break many plugins, which
	 * generally use this hook to reference JavaScript files.
	 */

	wp_footer();
?>
</body>
</html>
