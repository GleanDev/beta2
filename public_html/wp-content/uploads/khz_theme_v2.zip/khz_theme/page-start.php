<?php
/**
 * Template Name: Start
 *
 * A custom page template without sidebar.
 *
 * The "Template Name:" bit above allows this to be selectable
 * from a dropdown menu on the edit page screen.
 *
 * @package WordPress
 * @subpackage Twenty_Ten
 * @since Twenty Ten 1.0
 */

get_header(); ?>

					
			<div class="top_video">
				<div class="video_left">
					<div class="headlines">
						 <ul class="jcarousel-skin-tango headlines_scroll">
							<li>
								<p>KHZTV.COM is your All Hit Hotspot to stay wired to whats hot in media,.....on the Homepage, watch hot virals/videos, watch the KHZTV VJ shows or click on the call letters to see a live stream from one of our radio stations,..</p>
							</li>
							<li>
								<p>wired to whats hot in media KHZTV.COM is your All Hit Hotspot to stay ,.....on the Homepage, watch hot virals/videos, watch the KHZTV VJ shows or click on the call letters to see a live stream from one of our radio stations,..</p>
							</li>
							<li>
								<p>Hotspot to stay wired KHZTV.COM is your All Hit  to whats hot in media,.....on the Homepage, watch hot virals/videos, watch the KHZTV VJ shows or click on the call letters to see a live stream from one of our radio stations,..</p>
							</li>
							<li>
								<p>to stay wired KHZTV.COM is your All Hit Hotspot  to whats hot in media,.....on the Homepage, watch hot virals/videos, watch the KHZTV VJ shows or click on the call letters to see a live stream from one of our radio stations,..</p>
							</li>							
						  </ul>						
					</div>
					<div class="video_box">
						<img src="" class="big_img" alt="image" />
						<span class="blik"></span>
					</div>
				</div>
				<div class="video_right">
					<div id="tabs2" class="top_tab">
						<ul>
							<li><a href="#tabs-11">Featured Videos</a></li>
							<li><a href="#tabs-12">Schedule</a></li>									
						</ul>
						<div id="tabs-11">
							<ul>
								<?php if (have_posts()) : ?>
									<?php query_posts('category_name=Featured videos&posts_per_page=3'); ?>
										<?php while (have_posts()) : the_post(); ?>	
											<li>
												<?php if(has_post_thumbnail()) {the_post_thumbnail('large');}?>									
												<span><?php the_title();?></span>
												<?php the_excerpt();?>
												<a href="<?php the_permalink();?>">Watch &#187;</a>
											</li>
										<?php endwhile; ?>
									<?php wp_reset_query();?>
								<?php endif; ?>								
							</ul>
							<a href="#" class="browse">Browse All Videos</a>
						</div>
						<div id="tabs-12">
							<ul>
								<li>
									<img src="<?php bloginfo('template_url');?>/images/content_img_01.jpg" alt="image" />
									<span>Video Title 2</span>
									<p>Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos.</p>
									<a href="#">Watch &#187;</a>
								</li>
								<li>
									<img src="<?php bloginfo('template_url');?>/images/content_img_01.jpg" alt="image" />
									<span>Video Title 2</span>
									<p>Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos.</p>
									<a href="#">Watch &#187;</a>
								</li>
								<li>
									<img src="<?php bloginfo('template_url');?>/images/content_img_01.jpg" alt="image" />
									<span>Video Title 2</span>
									<p>Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos.</p>
									<a href="#">Watch &#187;</a>
								</li>
							</ul>
							<a href="#" class="browse">Browse All Videos</a>
						</div>
					</div>
				</div>
			</div>
		
		</div><!-- #main -->
		
		<div class="videos">
			<ul>
				<li><a href="#"><span>Video Title</span><img src="<?php bloginfo('template_url');?>/images/content_img_02.jpg" alt="image" /><em>Watch &#187;</em></a></li>
				<li><a href="#"><span>Video Title</span><img src="<?php bloginfo('template_url');?>/images/content_img_02.jpg" alt="image" /><em>Watch &#187;</em></a></li>
				<li><a href="#"><span>Video Title</span><img src="<?php bloginfo('template_url');?>/images/content_img_02.jpg" alt="image" /><em>Watch &#187;</em></a></li>
				<li><a href="#"><span>Video Title</span><img src="<?php bloginfo('template_url');?>/images/content_img_02.jpg" alt="image" /><em>Watch &#187;</em></a></li>
				<li><a href="#"><span>Video Title</span><img src="<?php bloginfo('template_url');?>/images/content_img_02.jpg" alt="image" /><em>Watch &#187;</em></a></li>
				<li><a href="#"><span>Video Title</span><img src="<?php bloginfo('template_url');?>/images/content_img_02.jpg" alt="image" /><em>Watch &#187;</em></a></li>
				<li><a href="#"><span>Video Title</span><img src="<?php bloginfo('template_url');?>/images/content_img_02.jpg" alt="image" /><em>Watch &#187;</em></a></li>
			</ul>
		</div>		
		<div class="main">
			<div id="tabs">
				<ul>
					<li><a href="#tabs-1">Top 5 Movies</a></li>
					<li><a href="#tabs-2">Top 5 Music</a></li>
					<li><a href="#tabs-3">Best Bargains</a></li>
					<li><a href="#tabs-4">Cyberstore</a></li>					
				</ul>
				<div id="tabs-1">
					  <ul class="jcarousel-skin-tango">
						<li>
							<img src="<?php bloginfo('template_url');?>/images/content_img_03.jpg"  alt="" />
							<span>Video Title</span>
							<p>Class aptent taciti sociosqu ad litora torquent per conubia nostra, per</p>
							<a href="#">Watch &#187;</a>
						</li>
						<li>
							<img src="<?php bloginfo('template_url');?>/images/content_img_03.jpg"  alt="" />
							<span>Video Title</span>
							<p>Class aptent taciti sociosqu ad litora torquent per conubia nostra, per</p>
							<a href="#">Watch &#187;</a>
						</li>
						<li>
							<img src="<?php bloginfo('template_url');?>/images/content_img_03.jpg"  alt="" />
							<span>Video Title</span>
							<p>Class aptent taciti sociosqu ad litora torquent per conubia nostra, per</p>
							<a href="#">Watch &#187;</a>
						</li>
						<li>
							<img src="<?php bloginfo('template_url');?>/images/content_img_03.jpg"  alt="" />
							<span>Video Title</span>
							<p>Class aptent taciti sociosqu ad litora torquent per conubia nostra, per</p>
							<a href="#">Watch &#187;</a>
						</li>
						<li>
							<img src="<?php bloginfo('template_url');?>/images/content_img_03.jpg"  alt="" />
							<span>Video Title</span>
							<p>Class aptent taciti sociosqu ad litora torquent per conubia nostra, per</p>
							<a href="#">Watch &#187;</a>
						</li>						
					  </ul>
				</div>
				<div id="tabs-2">
					<ul class="jcarousel-skin-tango">
						<li>
							<img src="<?php bloginfo('template_url');?>/images/content_img_03.jpg"  alt="" />
							<span>Video Title 2</span>
							<p>Class aptent taciti sociosqu ad litora torquent per conubia nostra, per</p>
							<a href="#">Watch &#187;</a>
						</li>
						<li>
							<img src="<?php bloginfo('template_url');?>/images/content_img_03.jpg"  alt="" />
							<span>Video Title 2</span>
							<p>Class aptent taciti sociosqu ad litora torquent per conubia nostra, per</p>
							<a href="#">Watch &#187;</a>
						</li>
						<li>
							<img src="<?php bloginfo('template_url');?>/images/content_img_03.jpg"  alt="" />
							<span>Video Title 2</span>
							<p>Class aptent taciti sociosqu ad litora torquent per conubia nostra, per</p>
							<a href="#">Watch &#187;</a>
						</li>
						<li>
							<img src="<?php bloginfo('template_url');?>/images/content_img_03.jpg"  alt="" />
							<span>Video Title 2</span>
							<p>Class aptent taciti sociosqu ad litora torquent per conubia nostra, per</p>
							<a href="#">Watch &#187;</a>
						</li>
						<li>
							<img src="<?php bloginfo('template_url');?>/images/content_img_03.jpg"  alt="" />
							<span>Video Title 2</span>
							<p>Class aptent taciti sociosqu ad litora torquent per conubia nostra, per</p>
							<a href="#">Watch &#187;</a>
						</li>						
					  </ul>
				</div>
				<div id="tabs-3">
					<ul class="jcarousel-skin-tango">
						<li>
							<img src="<?php bloginfo('template_url');?>/images/content_img_03.jpg"  alt="" />
							<span>Video Title 3</span>
							<p>Class aptent taciti sociosqu ad litora torquent per conubia nostra, per</p>
							<a href="#">Watch &#187;</a>
						</li>
						<li>
							<img src="<?php bloginfo('template_url');?>/images/content_img_03.jpg"  alt="" />
							<span>Video Title 3</span>
							<p>Class aptent taciti sociosqu ad litora torquent per conubia nostra, per</p>
							<a href="#">Watch &#187;</a>
						</li>
						<li>
							<img src="<?php bloginfo('template_url');?>/images/content_img_03.jpg"  alt="" />
							<span>Video Title 3</span>
							<p>Class aptent taciti sociosqu ad litora torquent per conubia nostra, per</p>
							<a href="#">Watch &#187;</a>
						</li>
						<li>
							<img src="<?php bloginfo('template_url');?>/images/content_img_03.jpg"  alt="" />
							<span>Video Title 3</span>
							<p>Class aptent taciti sociosqu ad litora torquent per conubia nostra, per</p>
							<a href="#">Watch &#187;</a>
						</li>
						<li>
							<img src="<?php bloginfo('template_url');?>/images/content_img_03.jpg"  alt="" />
							<span>Video Title 3</span>
							<p>Class aptent taciti sociosqu ad litora torquent per conubia nostra, per</p>
							<a href="#">Watch &#187;</a>
						</li>						
					  </ul>
				</div>
				<div id="tabs-4">
					<ul class="jcarousel-skin-tango">
						<li>
							<img src="<?php bloginfo('template_url');?>/images/content_img_03.jpg"  alt="" />
							<span>Video Title 4</span>
							<p>Class aptent taciti sociosqu ad litora torquent per conubia nostra, per</p>
							<a href="#">Watch &#187;</a>
						</li>
						<li>
							<img src="<?php bloginfo('template_url');?>/images/content_img_03.jpg"  alt="" />
							<span>Video Title 4</span>
							<p>Class aptent taciti sociosqu ad litora torquent per conubia nostra, per</p>
							<a href="#">Watch &#187;</a>
						</li>
						<li>
							<img src="<?php bloginfo('template_url');?>/images/content_img_03.jpg"  alt="" />
							<span>Video Title 4</span>
							<p>Class aptent taciti sociosqu ad litora torquent per conubia nostra, per</p>
							<a href="#">Watch &#187;</a>
						</li>
						<li>
							<img src="<?php bloginfo('template_url');?>/images/content_img_03.jpg"  alt="" />
							<span>Video Title 4</span>
							<p>Class aptent taciti sociosqu ad litora torquent per conubia nostra, per</p>
							<a href="#">Watch &#187;</a>
						</li>
						<li>
							<img src="<?php bloginfo('template_url');?>/images/content_img_03.jpg"  alt="" />
							<span>Video Title 4</span>
							<p>Class aptent taciti sociosqu ad litora torquent per conubia nostra, per</p>
							<a href="#">Watch &#187;</a>
						</li>						
					  </ul>
				</div>				
			</div>
			<div class="three_cols">
				<div class="col">
					<h2>Welcome To Our Site!</h2>
					<p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque sed enim at nisi vestibulum convallis et feugiat nulla. Aliquam vestibulum aliquam iaculis. Aliquam neque purus, fringilla sagittis eleifend sit amet, pulvinar eget orci. Duis posuere, leo id facilisis sollicitudin, ante ipsum iaculis quam, vel </p>
					<a href="#" class="more">READ MORE</a>
				</div>
				<div class="col">
					<h2>What We Offer</h2>
					<p>Maecenas convallis ligula placerat enim varius condimentum. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Quisque ut mauris vel lectus tempor consequat. Praesent congue, metus vel mattis fringilla, diam velit gravida nibh, id scelerisque lorem enim adipiscing dui. Integer </p>
					<a href="#" class="more">READ MORE</a>
				</div>
				<div class="col">
					<h2>Why Choose Us</h2>
					<p>Curabitur venenatis urna et purus tincidunt ut pellentesque tortor rutrum. Nam et velit sed tortor fringilla tempor faucibus non nibh. Cras dignissim pretium consequat. Vivamus orci metus, adipiscing nec gravida at, condimentum id odio. Mauris non felis odio. Nullam justo risus, tempus vel ullamcorper ut, tempor et </p>
					<a href="#" class="more">READ MORE</a>
				</div>
				<div class="clear"></div>
			</div>
<?php get_footer(); ?>

