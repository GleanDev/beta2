jQuery(document).ready(function() {	
	t = jQuery("#tabs2 #tabs-11 li:first").find('img').attr('src');	
		jQuery('.video_box').html('<img src="'+t+'" /><span class="blik"></span>');		
	jQuery('#tabs2 #tabs-11 li img').click(function(){
		t = jQuery(this).attr('src');
		jQuery('.video_box').html('<img src="'+t+'" /><span class="blik"></span>');
		
	});	
});