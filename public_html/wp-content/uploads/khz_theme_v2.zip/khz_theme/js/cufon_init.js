Cufon.replace('#access a', {fontFamily: 'Prototype', hover: true});
Cufon.replace('.ui-tabs .ui-tabs-nav li a', {fontFamily: 'Prototype', hover: true});
Cufon.replace('.browse, .more', {fontFamily: 'Prototype', hover: true});
Cufon.replace('.col h2, #content .entry-title, #content .entry-title a', {fontFamily: 'Prototype', hover: true});
