jQuery(document).ready(function() {
    jQuery('.jcarousel-skin-tango').jcarousel({scroll:1});
    
});