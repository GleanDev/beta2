jQuery(function(){
	jQuery('#tabs, #tabs2').tabs();
});